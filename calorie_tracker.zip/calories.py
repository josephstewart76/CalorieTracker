import requests
from openpyxl import Workbook, load_workbook
from openpyxl.utils import get_column_letter

def get_nutrition_info(fdc_id, api_key):
    # Use the USDA FoodData Central API to get nutrition facts by FDC ID
    api_url = f"https://api.nal.usda.gov/fdc/v1/food/{fdc_id}"
    params = {
        "api_key": api_key,
    }

    try:
        response = requests.get(api_url, params=params)
        response.raise_for_status()  # Raise an HTTPError for bad responses
        data = response.json()

        if "foodNutrients" in data and data["foodNutrients"]:
            nutrients = {}
            for nutrient in data["foodNutrients"]:
                nutrient_name = nutrient["nutrient"]["name"]
                nutrient_amount = nutrient.get("amount", 0)  # Use get method to handle missing "amount" key
                nutrients[nutrient_name] = nutrient_amount

            return nutrients
        else:
            return None
    except requests.exceptions.RequestException as e:
        print(f"Error during API request: {e}")
        print(f"Response Content: {response.content}")
        return None

def search_foods(query, api_key):
    # Use the USDA FoodData Central API to search for foods
    api_url = "https://api.nal.usda.gov/fdc/v1/foods/search"
    params = {
        "query": query,
        "api_key": api_key,
    }

    try:
        response = requests.get(api_url, params=params)
        response.raise_for_status()  # Raise an HTTPError for bad responses
        data = response.json()

        if "foods" in data and data["foods"]:
            return data["foods"]
        else:
            return None
    except requests.exceptions.RequestException as e:
        print(f"Error during API request: {e}")
        print(f"Response Content: {response.content}")
        return None

def display_search_results(foods):
    if foods:
        print("\nSearch Results:")
        for index, food in enumerate(foods, start=1):
            print(f"{index}. {food['description']} (FDC ID: {food['fdcId']})")
    else:
        print("No matching foods found.")

def add_to_spreadsheet(food_name, nutrients, spreadsheet_path="food_diary.xlsx"):
    try:
        # Load existing workbook if it exists
        workbook = load_workbook(spreadsheet_path)
    except FileNotFoundError:
        # Create a new workbook if it doesn't exist
        workbook = Workbook()

    # Select the active sheet
    sheet = workbook.active

    # Check if labels row already exists
    labels_exist = sheet["A1"].value == "Nutrient Labels"

    # If not, add nutrient labels row
    if not labels_exist:
        # Add nutrient labels row
        nutrient_labels = ["Nutrient Labels", "Calories"] + [nutrient for nutrient in list(nutrients.keys()) if nutrient != "Energy"]
        sheet.append(nutrient_labels)

    # Add data to the sheet
    data_row = [food_name, nutrients["Energy"]] + [nutrients[nutrient] for nutrient in list(nutrients.keys()) if nutrient != "Energy"]
    sheet.append(data_row)

    # Add formulas for the total row
    num_rows = sheet.max_row
    num_cols = sheet.max_column

    if num_rows > 2:  # Check if there is more than one row of data (excluding labels)
        for col in range(2, num_cols + 1):  # Start from column 2 as column 1 is for Food Name
            col_letter = get_column_letter(col)
            sheet[f"{col_letter}{num_rows + 1}"] = f"=SUM({col_letter}2:{col_letter}{num_rows})"

    # Save the workbook
    workbook.save(spreadsheet_path)
def main():
    api_key = "1Y4qf2IS2dbZakhYsUwpvgD5ZKcQmthXye6M2Uhn"  # Replace with your actual USDA API key
    query = input("Enter the food you want to search for: ")

    search_results = search_foods(query, api_key)

    if search_results:
        display_search_results(search_results)

        selected_index = int(input("\nEnter the number corresponding to the food you want to add to your diary (or enter 0 to exit): "))
        
        if selected_index != 0 and 1 <= selected_index <= len(search_results):
            selected_food = search_results[selected_index - 1]
            print(f"\nSelected Food: {selected_food['description']} (FDC ID: {selected_food['fdcId']})")

            # Fetch nutrition info for the selected food
            nutrients = get_nutrition_info(selected_food['fdcId'], api_key)

            if nutrients:
                print("\nNutrient Information:")
                for nutrient, value in nutrients.items():
                    print(f"{nutrient}: {value}")

                # Add the selected food and nutrient info to the spreadsheet
                add_to_spreadsheet(selected_food['description'], nutrients)
                print("Data added to the spreadsheet.")
            else:
                print("Failed to fetch nutrition information.")
        else:
            print("Exiting without adding a food to the diary.")
    else:
        print("No matching foods found.")

if __name__ == "__main__":
    main()
